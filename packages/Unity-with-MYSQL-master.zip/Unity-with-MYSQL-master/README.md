# Unity-with-MYSQL
Connect MYSQL with Unity

1. Import package which has been ziped as "UnityMySQL.rar". (You only need to load the Plugins)
2. Create two scripts
  -DatabaseHandler.cs
  -LoginGUI.cs

